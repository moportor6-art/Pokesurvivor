# Auditoría y preservación personal de Pokesurvivor

Fecha: 22 de noviembre de 2026, hora de México (captura UTC 23 de noviembre). Origen: https://pokesurvivor.com/.

## Resultado

Se conservaron **1,822 archivos originales**, **13,528,374 bytes**, sin editar imágenes, convertir formatos ni alterar el JavaScript descargado. Esta es una **copia parcial de preservación**, no una versión offline funcional certificada.

Se identificaron 47,683 URLs candidatas a partir de referencias y catálogos públicos. Estados de URL: {'descargado': 1822, 'rechazado_http_429': 14185, 'no_intentado': 31676}. Son candidatas: no equivalen a archivos existentes confirmados. Las variantes de gritos y huevos se derivaron de identificadores y están marcadas como tales.

La descarga recibió HTTP 429 (demasiadas solicitudes) y fue detenida al detectarse el límite. Un lote concurrente ya había acumulado numerosas respuestas 429 antes de la revisión del inventario. No se reintentaron para evadir el límite. HTTP 429 no demuestra que un archivo no exista; tampoco se determinó si lo produjo el origen o un intermediario. Los archivos restantes están marcados como no intentados. missing.csv contiene cada URL pendiente y su razón.

## Contenido y organización

resources/ conserva el dominio y las rutas con sus nombres originales. Las consultas ?v= se registran en el inventario y no se incorporan al nombre del archivo. Solo se observó una versión por ruta guardada. Los cuerpos HTTP se guardaron después de la descompresión normal del transporte, sin recodificar contenido.

audit/inventory.csv y inventory.json: URL, ruta local, estado, tamaño, SHA-256, motivo del descubrimiento y error disponible. audit/missing.csv: pendientes y fallos. audit/embedded-metadata.json: copia analítica derivada de los objetos públicos de animación, huevos y arenas. audit/cosmetics-catalog.json: catálogo analítico de retratos, marcos y skins. Estos JSON son derivados para consulta; no sustituyen a los archivos originales.

Tipos descargados por extensión: {'.js': 5, '.ico': 1, '.webmanifest': 1, '.json': 1, '.html': 5, '.css': 1, '.ttf': 2, '.png': 1686, '.mp3': 120}.

## Hallazgos técnicos

- HTML principal, CSS, scripts de arranque, JavaScript minificado (3.224.754 bytes), fuentes, manifiesto y service worker.
- El JavaScript contiene un catálogo de **1.538 entradas** de sprites/formas. Las hojas PNG se solicitan en assets/pokemon/ID/Animacion.png y assets/pokemon/ID/s/Animacion.png. El catálogo incluye tamaño de celda, cantidad de fotogramas, filas/direcciones, duraciones y anclajes; según la entrada aparecen Idle, Walk, Attack, Shoot, Charge, Hurt, Faint y otras. Una entrada no implica un Pokémon distinto ni que todas sus variantes se hayan recuperado.
- 13 fondos de arenas declarados; rutas assets/arenas/. Su existencia y recuperación individual están en el inventario. Mapas y terreno también se generan mediante código de chunks y temas; no se identificó un archivo de mapa independiente para cada zona.
- Gritos MP3 en assets/cries/ID.mp3. Hay música y efectos generados con Web Audio en el código; no se identificó una colección externa MP3/OGG de toda la música.
- Huevos PNG, retratos de perfil (25.011 rutas declaradas por máscaras de expresiones), marcos y skins. Los cosméticos se catalogaron después de detener las solicitudes y quedaron principalmente sin intentar.
- Elementos gráficos de interfaz se generan como SVG/blob en ejecución. No se exportaron ni convirtieron esos gráficos; su lógica permanece en el JavaScript original.

## Dependencias de red y alcance offline

| Dependencia | Función observada en código | Estado de preservación |
|---|---|---|
| pokesurvivor.com | Código, recursos, version.json, service worker | Parcial; detalle en inventario |
| www.gstatic.com/firebasejs/13.0.0/ | Bibliotecas Firebase app/auth | URLs identificadas; ver estado individual |
| jugadores.pokesurvivor.net y servicios Firebase | Identidad y autenticación | No se recuperan cuentas, tokens ni datos privados |
| ice.pokesurvivor.com | Mantenimiento, API /v1/d, partidas, clasificación, comunidad, ICE | Backend no incluido; no se llamó a endpoints autenticados |
| directo.pokesurvivor.com:8443 | Alternativa de servidor configurada por el sitio | Solo identificada en boot.js; no se utilizó |
| WebSocket/WebRTC, /v1/ice | Cooperativo y señalización | Servicios remotos no preservados |
| challenges.cloudflare.com | Verificación Turnstile en flujos protegidos | No se activó ni eludió |
| raw.githubusercontent.com/JPTER78/pokesurvivor-live/live/ | live.json, aviso.json, video.json | Referencias catalogadas; ver inventario |
| i.ytimg.com / YouTube | Miniaturas y anuncios de videos | Miniatura dinámica observada; no incluida |

El service worker guarda código y arte a demanda; excluye version.json y no conserva los recursos de otros dominios. No precarga el catálogo completo. La API y las funciones en la nube no se convierten en locales por descargar el frontend. El arranque tolera algunos fallos de mantenimiento, pero no se validó el comportamiento completo con la red desactivada.

Para evaluar offline faltan recursos señalados en missing.csv, revisar las dependencias de arranque y probar desde HTTP local sin acceso externo. Cuentas, sincronización, clasificación y cooperativo requieren sus servicios originales o un desarrollo adicional que está fuera de esta copia. No se modificó nada para simularlos.

## Verificación real y límites

En el navegador público se comprobó: pantalla inicial, acceso como invitado, cuestionario, menú con Scorbunny y comienzo de una partida en el bosque. No se inició sesión, aceptaron acuerdos, alteraron cuentas ni sortearon barreras. No se verificaron todas las regiones, jefes, animaciones o modos. No se obtuvo un HAR completo: la inspección de dependencias combina DOM visible y análisis del código público, no una captura exhaustiva de tráfico.

La segunda instancia local de Chromium no pudo arrancar por restricciones del entorno; la comprobación visual se hizo en el navegador disponible. No se hizo una prueba del ZIP servido localmente ni de ejecución sin red. Los hashes permiten verificar la integridad de lo guardado, no certificar su equivalencia con todas las versiones del sitio.

La herramienta reference-to-game se revisó mediante su README público. Se orienta a recrear juegos a partir de referencias, no a copiar con fidelidad los archivos originales de una web; por ello no se instaló ni se usó para regenerar recursos.

## Créditos

La interfaz del sitio declara: proyecto fan sin ánimo de lucro; sprites SpriteCollab (CC BY-NC 4.0); Pokémon © Nintendo/Creatures/GAME FREAK. Se conserva ese aviso y los originales disponibles. Este informe no concede permisos adicionales de uso o redistribución.
